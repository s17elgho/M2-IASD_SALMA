This project contains our group's work on assignment1 :<br>

Eric N'guessan<br>
Boulif Kaoutar<br>
Salma Elghourbal<br>

It contains :<br>
  * Matrix_factorization_final.ipynb : Jupyter notebook containing all our code, graphs and comments<br>
  * Data used : - small dataset (movies.csv and ratings.csv)  http://files.grouplens.org/datasets/movielens/ml-latest-small-README.html<br>  
                - a slightly larger dataset (movies.dat) https://grouplens.org/datasets/movielens/1m/  <br> 
  * Rapport_MF.pdf  : Our final report pdf which explains our methods and results<br>
  * Presentation_MF : Our powerpoint for the final presentation of Thursday<br>
 
 We hope you enjoy reading our work ! 
